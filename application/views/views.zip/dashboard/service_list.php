            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">
                         <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <h4>Service</h4>
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                                            <li class="breadcrumb-item active">Service</li>
                                        </ol>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        <!-- end row -->
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                      <div class="card-body">
                                        <h4 class="card-title">Service Category List</h4>
                                         <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>S.No</th>
                                                    <th>Image</th>
                                                    <th>Category</th>
                                                    <th>Title</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                             <tbody>
                                                
                                             
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div> <!-- end row -->
                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->
<script>
$("#forms").submit(function(event) {
        event.preventDefault();
        $.ajax({
                type: "POST", 
                url: '<?php echo base_url('Admin/Service_category/add');?>',
                dataType:'json',
                data: new FormData(this), 
                contentType: false,
                cache: false,
                processData:false,
                beforeSend:function()
                {},
                success:function(responce)
                {
                  if(responce.status==0)
                  {
                 
                   toastr.error(responce.message);
                  }else if(responce.status==1)
                  {

                    toastr.success(responce.message);
                    window.location.href= '<?php echo base_url('Admin/Service_category');?>';
                    
                   
                  }  
                },
                error:function()
                {
                  toastr.error('Something Went Wrong..');
                },
                complete:function()
                {
                }
            });
    })
</script>


          